$(document).ready(function(){
	$(".main").onepage_scroll({
		dotstyle: "fillup",
		sectionContainer: "section",
		responsiveFallback: 600,
		loop: true
	});
});